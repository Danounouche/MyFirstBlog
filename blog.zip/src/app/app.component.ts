import { Component } from '@angular/core';
import { resolve, reject } from 'q';
import { Post } from './Models/Post';
import { post } from 'selenium-webdriver/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
/*   isAuth = false;
  lastUpdate = new Promise((resolve) => {
    setTimeout(() => {
      const date = new Date();
      resolve(date);
    }, 2000);
  }); */
  posts: Array<Post> = [];

  /* appareils = [
    {
      name: 'Machine à laver',
      status: 'éteint'
    },
    {
      name: 'Frigo',
      status: 'allumé'
    },
    {
      name: 'Ordinateur',
      status: 'éteint'
    }
  ]; */

  constructor() {
/*     setTimeout(
      () => {
        this.isAuth = true;
      },
      4000); */

      this.posts.push(new Post('Mon premier post', 'Salut voivi mon premier blog....sympa non???', 1));
      this.posts.push(new Post('Mon deuxieme post', 'Salut voivi mon premier blog....sympa non???', -1));
      this.posts.push(new Post('Encore un  post', 'Salut voivi mon premier blog....sympa non???', 0));
  }

/*   onAllumer() {
    console.log('On allume tout !');
  } */
}
