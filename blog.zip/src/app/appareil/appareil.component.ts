import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-appareil',
  templateUrl: './appareil.component.html',
  styleUrls: ['./appareil.component.scss']
})
export class AppareilComponent implements OnInit {
  @Input() appareilName;
  @Input() appareilStatus;

  constructor() { }

  ngOnInit() {
  }

  getStatus(): string {
    return this.appareilStatus;
  }

  getColor(): string {
    return this.appareilStatus === 'éteint' ? 'red' : 'green';
  }

}
