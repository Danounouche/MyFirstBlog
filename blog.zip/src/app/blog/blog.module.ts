import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostListItemComponent } from './post-list-item/post-list-item.component';
import { PostListComponent } from './post-list/post-list.component';

@NgModule({
  imports: [CommonModule],
  declarations: [PostListItemComponent, PostListComponent],
  exports: [PostListItemComponent, PostListComponent]
})
export class BlogModule { }
